# micon font

this font include mdl2 icons and webbrand icons

- 1095 orginal icons (path)
- 1415 (orginal name + alias name) => in css
